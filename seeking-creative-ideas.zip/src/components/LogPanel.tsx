import { useEffect, useRef } from "react";
import { AgentLog } from "../types";

interface Props {
  logs: AgentLog[];
  onClear: () => void;
}

const levelStyle: Record<AgentLog["level"], string> = {
  info:    "text-gray-300",
  success: "text-green-400",
  warn:    "text-yellow-400",
  error:   "text-red-400",
};

const levelPrefix: Record<AgentLog["level"], string> = {
  info:    "INFO ",
  success: "DONE ",
  warn:    "WARN ",
  error:   "ERR  ",
};

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function formatTime(d: Date) {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

export default function LogPanel({ logs, onClear }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Auto-scroll to top (newest log is first)
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
  }, [logs.length]);

  return (
    <div className="flex flex-col h-full bg-gray-950 rounded-2xl overflow-hidden border border-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-gray-900 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>
          <span className="text-gray-400 text-xs font-mono ml-2">Agent Runtime Log</span>
          <span className="bg-gray-700 text-gray-300 text-xs px-2 py-0.5 rounded-full font-mono">
            {logs.length} lines
          </span>
        </div>
        <button
          onClick={onClear}
          className="text-xs text-gray-500 hover:text-gray-300 transition-colors font-mono"
        >
          [clear]
        </button>
      </div>

      {/* Log content */}
      <div ref={containerRef} className="flex-1 overflow-y-auto p-4 space-y-1 font-mono text-xs">
        {logs.length === 0 ? (
          <div className="text-gray-600 text-center mt-8">
            <p>▌ 等待 Agent 启动...</p>
            <p className="mt-1 text-gray-700">选择一条流水线并点击运行</p>
          </div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className="flex gap-3 leading-relaxed group">
              <span className="text-gray-600 shrink-0 w-16">{formatTime(log.timestamp)}</span>
              <span className={`shrink-0 w-10 font-semibold ${levelStyle[log.level]}`}>
                {levelPrefix[log.level]}
              </span>
              <span className="text-purple-400 shrink-0 w-24 truncate">[{log.agentName}]</span>
              <span className={`${levelStyle[log.level]} break-words flex-1`}>{log.message}</span>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
