import { Agent } from "../types";

interface Props {
  agents: Agent[];
  tasks: { status: string }[];
}

function formatTokens(n: number) {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(0)}K`;
  return String(n);
}

export default function MetricsBar({ agents, tasks }: Props) {
  const totalTokens = agents.reduce((s, a) => s + a.tokensUsed, 0);
  const totalTasks = agents.reduce((s, a) => s + a.tasksCompleted, 0);
  const runningAgents = agents.filter((a) => a.status === "running").length;
  const doneTasks = tasks.filter((t) => t.status === "done").length;

  const metrics = [
    {
      icon: "🤖",
      label: "活跃 Agent",
      value: `${runningAgents} / ${agents.length}`,
      sub: "当前运行中",
      color: runningAgents > 0 ? "text-blue-600" : "text-gray-700",
      bg: runningAgents > 0 ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200",
    },
    {
      icon: "✅",
      label: "累计完成任务",
      value: totalTasks.toLocaleString(),
      sub: `本次 ${doneTasks} 个`,
      color: "text-green-600",
      bg: "bg-green-50 border-green-200",
    },
    {
      icon: "⚡",
      label: "累计 Token 用量",
      value: formatTokens(totalTokens),
      sub: "所有 Agent 合计",
      color: "text-indigo-600",
      bg: "bg-indigo-50 border-indigo-200",
    },
    {
      icon: "📊",
      label: "流水线步骤",
      value: `${doneTasks} 完成`,
      sub: tasks.length > 0 ? `共 ${tasks.length} 步` : "尚未运行",
      color: "text-purple-600",
      bg: "bg-purple-50 border-purple-200",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {metrics.map((m) => (
        <div key={m.label} className={`rounded-2xl border p-4 transition-all duration-300 ${m.bg}`}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">{m.icon}</span>
            <p className="text-xs text-gray-500 font-medium">{m.label}</p>
          </div>
          <p className={`text-2xl font-black ${m.color}`}>{m.value}</p>
          <p className="text-xs text-gray-400 mt-0.5">{m.sub}</p>
        </div>
      ))}
    </div>
  );
}
