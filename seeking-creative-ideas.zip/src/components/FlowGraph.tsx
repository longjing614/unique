import { Agent } from "../types";

interface Props {
  agents: Agent[];
}

// Fixed positions for a layered DAG layout
const NODE_POSITIONS: Record<string, { x: number; y: number }> = {
  orchestrator:   { x: 360, y: 40 },
  "data-collector": { x: 120, y: 160 },
  "content-agent":  { x: 320, y: 160 },
  "seo-agent":      { x: 520, y: 160 },
  "ad-agent":       { x: 680, y: 160 },
  publisher:        { x: 420, y: 280 },
  analyst:          { x: 200, y: 280 },
};

const EDGES: [string, string][] = [
  ["orchestrator", "data-collector"],
  ["orchestrator", "content-agent"],
  ["orchestrator", "seo-agent"],
  ["orchestrator", "ad-agent"],
  ["data-collector", "analyst"],
  ["content-agent", "seo-agent"],
  ["content-agent", "publisher"],
  ["seo-agent", "publisher"],
  ["ad-agent", "analyst"],
  ["publisher", "analyst"],
  ["analyst", "orchestrator"],
];

const NODE_R = 28;
const SVG_W = 820;
const SVG_H = 360;

function getStatusColor(status: Agent["status"]) {
  switch (status) {
    case "running": return "#3b82f6";
    case "success": return "#22c55e";
    case "error":   return "#ef4444";
    case "waiting": return "#f59e0b";
    default:        return "#9ca3af";
  }
}

function getStatusGlow(status: Agent["status"]) {
  if (status === "running") return "drop-shadow(0 0 8px rgba(59,130,246,0.8))";
  if (status === "success") return "drop-shadow(0 0 6px rgba(34,197,94,0.6))";
  return "none";
}

export default function FlowGraph({ agents }: Props) {
  const agentMap = Object.fromEntries(agents.map((a) => [a.id, a]));

  return (
    <div className="w-full overflow-x-auto">
      <svg
        viewBox={`0 0 ${SVG_W} ${SVG_H}`}
        className="w-full"
        style={{ minWidth: 600, height: SVG_H }}
      >
        {/* Defs */}
        <defs>
          <marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
            <path d="M0,0 L0,6 L8,3 z" fill="#cbd5e1" />
          </marker>
          <marker id="arrow-active" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
            <path d="M0,0 L0,6 L8,3 z" fill="#3b82f6" />
          </marker>
          {agents.map((a) => (
            <radialGradient key={a.id} id={`grad-${a.id}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="white" />
              <stop offset="100%" stopColor={getStatusColor(a.status)} stopOpacity="0.15" />
            </radialGradient>
          ))}
        </defs>

        {/* Edges */}
        {EDGES.map(([from, to]) => {
          const fp = NODE_POSITIONS[from];
          const tp = NODE_POSITIONS[to];
          if (!fp || !tp) return null;
          const fromAgent = agentMap[from];
          const toAgent = agentMap[to];
          const isActive = fromAgent?.status === "running" || toAgent?.status === "running";

          // Calculate offset to circle border
          const dx = tp.x - fp.x;
          const dy = tp.y - fp.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const ux = dx / dist;
          const uy = dy / dist;
          const x1 = fp.x + ux * NODE_R;
          const y1 = fp.y + uy * NODE_R;
          const x2 = tp.x - ux * (NODE_R + 6);
          const y2 = tp.y - uy * (NODE_R + 6);

          return (
            <line
              key={`${from}-${to}`}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={isActive ? "#3b82f6" : "#cbd5e1"}
              strokeWidth={isActive ? 2.5 : 1.5}
              strokeDasharray={isActive ? "none" : "5,3"}
              markerEnd={isActive ? "url(#arrow-active)" : "url(#arrow)"}
              className="transition-all duration-500"
            />
          );
        })}

        {/* Nodes */}
        {agents.map((agent) => {
          const pos = NODE_POSITIONS[agent.id];
          if (!pos) return null;
          const color = getStatusColor(agent.status);
          const glow = getStatusGlow(agent.status);

          return (
            <g
              key={agent.id}
              transform={`translate(${pos.x},${pos.y})`}
              style={{ filter: glow }}
              className="transition-all duration-300"
            >
              {/* Pulse ring for running */}
              {agent.status === "running" && (
                <circle r={NODE_R + 8} fill="none" stroke="#3b82f6" strokeWidth="2" opacity="0.4">
                  <animate attributeName="r" values={`${NODE_R + 4};${NODE_R + 14};${NODE_R + 4}`} dur="1.5s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.6;0;0.6" dur="1.5s" repeatCount="indefinite" />
                </circle>
              )}

              {/* Circle bg */}
              <circle r={NODE_R} fill={`url(#grad-${agent.id})`} stroke={color} strokeWidth="2.5" />

              {/* Icon */}
              <text textAnchor="middle" dominantBaseline="central" fontSize="18" y="-5">
                {agent.icon}
              </text>

              {/* Name */}
              <text
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="9"
                fontWeight="600"
                fill="#374151"
                y={NODE_R + 14}
              >
                {agent.name}
              </text>

              {/* Status dot */}
              <circle cx={NODE_R - 6} cy={-(NODE_R - 6)} r="5" fill={color} stroke="white" strokeWidth="1.5" />
            </g>
          );
        })}
      </svg>
    </div>
  );
}
