import { Agent } from "../types";

interface Props {
  agent: Agent;
  isActive: boolean;
}

const statusConfig = {
  idle: { label: "待机", dot: "bg-gray-400", ring: "" },
  running: { label: "运行中", dot: "bg-blue-500 animate-pulse", ring: "ring-2 ring-blue-300" },
  success: { label: "完成", dot: "bg-green-500", ring: "ring-2 ring-green-200" },
  error: { label: "错误", dot: "bg-red-500", ring: "ring-2 ring-red-200" },
  waiting: { label: "等待", dot: "bg-yellow-400", ring: "ring-2 ring-yellow-200" },
};

function formatTokens(n: number) {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(0)}K`;
  return String(n);
}

export default function AgentCard({ agent, isActive }: Props) {
  const sc = statusConfig[agent.status];

  return (
    <div
      className={`relative rounded-2xl border-2 p-4 transition-all duration-300 ${agent.borderColor} ${agent.bgColor} ${
        isActive ? sc.ring : ""
      } ${agent.status === "running" ? "shadow-lg scale-[1.02]" : "shadow-sm"}`}
    >
      {/* Status dot */}
      <div className="absolute top-3 right-3 flex items-center gap-1.5">
        <div className={`w-2 h-2 rounded-full ${sc.dot}`} />
        <span className="text-xs text-gray-500 font-medium">{sc.label}</span>
      </div>

      {/* Header */}
      <div className="flex items-center gap-3 mb-3">
        <div className="text-3xl">{agent.icon}</div>
        <div>
          <p className="font-bold text-gray-900 text-sm leading-tight">{agent.name}</p>
          <p className={`text-xs font-semibold ${agent.color}`}>{agent.role}</p>
        </div>
      </div>

      {/* Current task */}
      {agent.status === "running" && agent.currentTask && (
        <div className="mb-3 bg-white/70 rounded-xl px-3 py-2 border border-blue-100">
          <p className="text-xs text-blue-600 font-medium truncate">⚡ {agent.currentTask}</p>
        </div>
      )}

      {/* Description */}
      <p className="text-xs text-gray-500 leading-relaxed mb-3 line-clamp-2">{agent.description}</p>

      {/* Capabilities */}
      <div className="flex flex-wrap gap-1 mb-3">
        {agent.capabilities.map((cap) => (
          <span key={cap} className="text-xs bg-white/80 text-gray-600 px-2 py-0.5 rounded-full border border-gray-200">
            {cap}
          </span>
        ))}
      </div>

      {/* Stats */}
      <div className="flex gap-3 pt-2 border-t border-white/50">
        <div className="flex-1 text-center">
          <p className="text-xs text-gray-400">已完成任务</p>
          <p className="text-sm font-bold text-gray-700">{agent.tasksCompleted}</p>
        </div>
        <div className="w-px bg-gray-200" />
        <div className="flex-1 text-center">
          <p className="text-xs text-gray-400">Token 用量</p>
          <p className="text-sm font-bold text-gray-700">{formatTokens(agent.tokensUsed)}</p>
        </div>
      </div>
    </div>
  );
}
