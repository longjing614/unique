import { Pipeline } from "../types";
import { INITIAL_AGENTS } from "../data/agents";

interface Props {
  pipelines: Pipeline[];
  activePipelineId: string | null;
  isRunning: boolean;
  onRun: (id: string) => void;
  onStop: () => void;
}

const agentMap = Object.fromEntries(INITIAL_AGENTS.map((a) => [a.id, a]));

const triggerLabel: Record<Pipeline["triggerType"], string> = {
  manual:   "手动触发",
  schedule: "定时触发",
  event:    "事件触发",
};

const triggerColor: Record<Pipeline["triggerType"], string> = {
  manual:   "bg-gray-100 text-gray-600",
  schedule: "bg-indigo-100 text-indigo-600",
  event:    "bg-amber-100 text-amber-700",
};

function formatTime(d?: Date) {
  if (!d) return "从未运行";
  return d.toLocaleTimeString("zh-CN");
}

export default function PipelinePanel({ pipelines, activePipelineId, isRunning, onRun, onStop }: Props) {
  return (
    <div className="space-y-4">
      {pipelines.map((pipeline) => {
        const isActive = pipeline.id === activePipelineId;
        const isThisRunning = isActive && isRunning;

        return (
          <div
            key={pipeline.id}
            className={`rounded-2xl border-2 p-5 transition-all duration-300 ${
              isThisRunning
                ? "border-blue-300 bg-blue-50 shadow-md"
                : pipeline.status === "success"
                ? "border-green-200 bg-green-50"
                : "border-gray-200 bg-white"
            }`}
          >
            {/* Top row */}
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-gray-900 text-sm">{pipeline.name}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${triggerColor[pipeline.triggerType]}`}>
                    {triggerLabel[pipeline.triggerType]}
                  </span>
                  {pipeline.status === "success" && (
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ 已完成</span>
                  )}
                  {isThisRunning && (
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium animate-pulse">
                      ⚡ 运行中
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">{pipeline.description}</p>
                <p className="text-xs text-gray-400 mt-1">上次运行：{formatTime(pipeline.lastRun)}</p>
              </div>

              <div className="shrink-0">
                {isThisRunning ? (
                  <button
                    onClick={onStop}
                    className="px-4 py-2 text-sm font-semibold rounded-xl bg-red-500 hover:bg-red-600 text-white transition-colors"
                  >
                    ⏹ 停止
                  </button>
                ) : (
                  <button
                    onClick={() => onRun(pipeline.id)}
                    disabled={isRunning}
                    className={`px-4 py-2 text-sm font-semibold rounded-xl transition-colors ${
                      isRunning
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
                    }`}
                  >
                    ▶ 运行
                  </button>
                )}
              </div>
            </div>

            {/* Steps */}
            <div className="mt-3 flex items-center gap-1 flex-wrap">
              {pipeline.steps.map((step, idx) => {
                const agent = agentMap[step.agentId];
                return (
                  <div key={idx} className="flex items-center gap-1">
                    <div
                      className={`flex items-center gap-1 text-xs px-2 py-1 rounded-lg font-medium transition-all ${
                        isThisRunning && agent
                          ? agent.bgColor + " " + agent.color + " " + agent.borderColor + " border"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      <span>{agent?.icon}</span>
                      <span className="hidden sm:inline">{agent?.name}</span>
                    </div>
                    {idx < pipeline.steps.length - 1 && (
                      <span className="text-gray-300 text-xs">→</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
