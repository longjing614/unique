import { AgentTask } from "../types";
import { INITIAL_AGENTS } from "../data/agents";

interface Props {
  tasks: AgentTask[];
}

function formatDuration(start?: Date, end?: Date) {
  if (!start) return "-";
  const ms = (end ?? new Date()).getTime() - start.getTime();
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

const agentMap = Object.fromEntries(INITIAL_AGENTS.map((a) => [a.id, a]));

export default function TaskList({ tasks }: Props) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p className="text-4xl mb-3">📋</p>
        <p className="text-sm">尚无任务记录</p>
        <p className="text-xs mt-1 text-gray-500">运行流水线后，任务将在此显示</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {tasks.map((task) => {
        const agent = agentMap[task.agentId];
        const isDone = task.status === "done";
        const isFailed = task.status === "failed";
        const isRunning = task.status === "running";

        return (
          <div
            key={task.id}
            className={`rounded-xl border p-3 transition-all duration-300 ${
              isRunning
                ? "border-blue-200 bg-blue-50"
                : isDone
                ? "border-green-200 bg-green-50"
                : isFailed
                ? "border-red-200 bg-red-50"
                : "border-gray-200 bg-gray-50"
            }`}
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-base">{agent?.icon ?? "🤖"}</span>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-gray-700 truncate">{task.title}</p>
                  <p className={`text-xs ${agent?.color ?? "text-gray-500"} font-medium`}>
                    {agent?.name} · {agent?.role}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                {isRunning && (
                  <span className="inline-flex items-center gap-1 text-xs text-blue-600 font-medium bg-blue-100 px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
                    运行中
                  </span>
                )}
                {isDone && (
                  <span className="text-xs text-green-600 font-medium bg-green-100 px-2 py-0.5 rounded-full">
                    ✓ 完成
                  </span>
                )}
                {isFailed && (
                  <span className="text-xs text-red-600 font-medium bg-red-100 px-2 py-0.5 rounded-full">
                    ✗ 失败
                  </span>
                )}
                <span className="text-xs text-gray-400">
                  {formatDuration(task.startedAt, task.finishedAt)}
                </span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  isDone ? "bg-green-500" : isFailed ? "bg-red-500" : "bg-blue-500"
                }`}
                style={{ width: `${task.progress}%` }}
              />
            </div>

            {task.output && isDone && (
              <p className="text-xs text-gray-500 mt-1.5 truncate">{task.output}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}
