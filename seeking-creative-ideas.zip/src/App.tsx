import { useState } from "react";
import { useAgentSystem } from "./hooks/useAgentSystem";
import AgentCard from "./components/AgentCard";
import FlowGraph from "./components/FlowGraph";
import LogPanel from "./components/LogPanel";
import TaskList from "./components/TaskList";
import PipelinePanel from "./components/PipelinePanel";
import MetricsBar from "./components/MetricsBar";

type Tab = "overview" | "agents" | "pipelines" | "tasks" | "logs";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "overview",   label: "总览",      icon: "🗺️"  },
  { id: "agents",     label: "Agent 节点", icon: "🤖"  },
  { id: "pipelines",  label: "流水线",     icon: "🔄"  },
  { id: "tasks",      label: "任务记录",   icon: "📋"  },
  { id: "logs",       label: "运行日志",   icon: "🖥️"  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const {
    agents,
    logs,
    tasks,
    pipelines,
    activePipelineId,
    isRunning,
    runPipeline,
    stopAll,
    clearLogs,
  } = useAgentSystem();

  const runningAgent = agents.find((a) => a.status === "running");

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex flex-col">
      {/* Top Nav */}
      <header className="bg-gray-900 border-b border-gray-800 sticky top-0 z-50">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-lg">
                🧠
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-bold text-white leading-none">MultiAgent OS</p>
                <p className="text-xs text-gray-400 leading-none mt-0.5">多Agent协同运营自动化系统</p>
              </div>
            </div>

            {/* Status pill */}
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${
              isRunning ? "bg-blue-900/50 text-blue-300 border border-blue-700" : "bg-gray-800 text-gray-400 border border-gray-700"
            }`}>
              <div className={`w-2 h-2 rounded-full ${isRunning ? "bg-blue-400 animate-pulse" : "bg-gray-500"}`} />
              {isRunning
                ? `⚡ ${runningAgent?.name ?? "Agent"} 执行中...`
                : "● 系统待机"}
            </div>

            {/* Quick actions */}
            <div className="flex items-center gap-2">
              {isRunning && (
                <button
                  onClick={stopAll}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-600 hover:bg-red-700 text-white transition-colors"
                >
                  ⏹ 停止
                </button>
              )}
              <button
                onClick={() => setActiveTab("logs")}
                className="px-3 py-1.5 text-xs font-medium rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 transition-colors"
              >
                🖥️ 日志
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-gray-900 border-b border-gray-800">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6">
          <div className="flex gap-1 overflow-x-auto">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-indigo-500 text-indigo-400"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 max-w-screen-xl mx-auto w-full px-4 sm:px-6 py-6">

        {/* ── OVERVIEW ── */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <MetricsBar agents={agents} tasks={tasks} />

            {/* Flow graph */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="font-bold text-white">Agent 协作拓扑图</h2>
                  <p className="text-xs text-gray-400 mt-0.5">实时展示各 Agent 运行状态与数据流向</p>
                </div>
                <div className="flex gap-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-gray-400 inline-block"/>待机</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block animate-pulse"/>运行</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500 inline-block"/>完成</span>
                </div>
              </div>
              <FlowGraph agents={agents} />
            </div>

            {/* Split: pipelines + log preview */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
                <h2 className="font-bold text-white mb-4">🔄 快速启动流水线</h2>
                <PipelinePanel
                  pipelines={pipelines}
                  activePipelineId={activePipelineId}
                  isRunning={isRunning}
                  onRun={runPipeline}
                  onStop={stopAll}
                />
              </div>

              <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5 flex flex-col" style={{ minHeight: 320 }}>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-bold text-white">🖥️ 实时日志</h2>
                  <button onClick={() => setActiveTab("logs")} className="text-xs text-indigo-400 hover:text-indigo-300">
                    查看全部 →
                  </button>
                </div>
                <div className="flex-1 bg-gray-950 rounded-xl overflow-hidden border border-gray-800">
                  <div className="h-full overflow-y-auto p-3 font-mono text-xs space-y-1">
                    {logs.length === 0 ? (
                      <p className="text-gray-600 text-center pt-8">运行流水线后日志将在此显示...</p>
                    ) : (
                      logs.slice(0, 30).map((log) => (
                        <div key={log.id} className="flex gap-2">
                          <span className="text-gray-600 shrink-0">
                            {`${String(log.timestamp.getHours()).padStart(2,"0")}:${String(log.timestamp.getMinutes()).padStart(2,"0")}:${String(log.timestamp.getSeconds()).padStart(2,"0")}`}
                          </span>
                          <span className="text-purple-400 shrink-0 w-20 truncate">[{log.agentName}]</span>
                          <span className={
                            log.level === "success" ? "text-green-400" :
                            log.level === "warn" ? "text-yellow-400" :
                            log.level === "error" ? "text-red-400" : "text-gray-300"
                          }>{log.message}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── AGENTS ── */}
        {activeTab === "agents" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-white">Agent 节点管理</h2>
              <p className="text-sm text-gray-400 mt-1">共 {agents.length} 个专属 Agent，各司其职，协同完成运营自动化闭环</p>
            </div>
            <MetricsBar agents={agents} tasks={tasks} />
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {agents.map((agent) => (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  isActive={agent.status === "running"}
                />
              ))}
            </div>
          </div>
        )}

        {/* ── PIPELINES ── */}
        {activeTab === "pipelines" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-white">自动化流水线</h2>
              <p className="text-sm text-gray-400 mt-1">
                选择一条流水线运行，系统将自动协调各 Agent 完成端到端任务
              </p>
            </div>

            {/* Architecture description */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
              <h3 className="font-semibold text-white mb-3">🏗️ 系统架构说明</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  {
                    icon: "🧠",
                    title: "Orchestrator 主调度",
                    desc: "接收目标 → 任务拆解 → 下发子任务 → 汇聚结果，是整个系统的大脑中枢",
                  },
                  {
                    icon: "🔗",
                    title: "多 Agent 并行 / 串行",
                    desc: "支持 DAG（有向无环图）任务依赖，无依赖 Agent 并行执行，有依赖的按序执行",
                  },
                  {
                    icon: "🔄",
                    title: "闭环反馈机制",
                    desc: "DataAnalyst 将结果反馈回 Orchestrator，支持动态调整策略，实现自适应优化",
                  },
                ].map((item) => (
                  <div key={item.title} className="bg-gray-800 rounded-xl p-4">
                    <div className="text-2xl mb-2">{item.icon}</div>
                    <p className="text-sm font-semibold text-white mb-1">{item.title}</p>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
              <PipelinePanel
                pipelines={pipelines}
                activePipelineId={activePipelineId}
                isRunning={isRunning}
                onRun={runPipeline}
                onStop={stopAll}
              />
            </div>
          </div>
        )}

        {/* ── TASKS ── */}
        {activeTab === "tasks" && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">任务执行记录</h2>
                <p className="text-sm text-gray-400 mt-1">本次流水线 {tasks.length} 个任务，{tasks.filter(t=>t.status==="done").length} 个已完成</p>
              </div>
              {!isRunning && tasks.length === 0 && (
                <button
                  onClick={() => setActiveTab("pipelines")}
                  className="px-4 py-2 text-sm font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                >
                  ▶ 去运行流水线
                </button>
              )}
            </div>
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
              <TaskList tasks={tasks} />
            </div>
          </div>
        )}

        {/* ── LOGS ── */}
        {activeTab === "logs" && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">运行日志</h2>
                <p className="text-sm text-gray-400 mt-1">实时记录所有 Agent 的执行过程与状态输出</p>
              </div>
            </div>
            <div style={{ height: "calc(100vh - 260px)", minHeight: 400 }}>
              <LogPanel logs={logs} onClear={clearLogs} />
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 py-4 mt-6">
        <div className="max-w-screen-xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-gray-500">
            🧠 MultiAgent OS · 多Agent协同运营自动化系统
          </p>
          <div className="flex gap-4 text-xs text-gray-600">
            <span>7 个专属 Agent</span>
            <span>·</span>
            <span>3 条自动化流水线</span>
            <span>·</span>
            <span>DAG 任务调度</span>
            <span>·</span>
            <span>闭环反馈机制</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
