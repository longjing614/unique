export type AgentStatus = "idle" | "running" | "success" | "error" | "waiting";
export type TaskStatus = "pending" | "running" | "done" | "failed";
export type LogLevel = "info" | "success" | "warn" | "error";

export interface AgentLog {
  id: string;
  agentId: string;
  agentName: string;
  level: LogLevel;
  message: string;
  timestamp: Date;
}

export interface AgentTask {
  id: string;
  title: string;
  agentId: string;
  status: TaskStatus;
  progress: number;
  startedAt?: Date;
  finishedAt?: Date;
  output?: string;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  icon: string;
  color: string;
  bgColor: string;
  borderColor: string;
  status: AgentStatus;
  description: string;
  capabilities: string[];
  currentTask?: string;
  tasksCompleted: number;
  tokensUsed: number;
  upstreamIds: string[];
  downstreamIds: string[];
}

export interface Pipeline {
  id: string;
  name: string;
  description: string;
  triggerType: "manual" | "schedule" | "event";
  lastRun?: Date;
  status: "idle" | "running" | "success" | "failed";
  steps: PipelineStep[];
}

export interface PipelineStep {
  agentId: string;
  taskTemplate: string;
  dependsOn: string[];
}

export interface Metric {
  label: string;
  value: string;
  delta: string;
  positive: boolean;
  icon: string;
}
