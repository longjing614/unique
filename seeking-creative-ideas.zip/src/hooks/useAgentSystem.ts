import { useState, useCallback, useRef } from "react";
import { Agent, AgentLog, AgentTask, Pipeline } from "../types";
import { INITIAL_AGENTS, PIPELINES, TASK_SCRIPTS } from "../data/agents";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function useAgentSystem() {
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [tasks, setTasks] = useState<AgentTask[]>([]);
  const [pipelines, setPipelines] = useState<Pipeline[]>(PIPELINES);
  const [activePipelineId, setActivePipelineId] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const timeoutsRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const addLog = useCallback(
    (agentId: string, agentName: string, message: string, level: AgentLog["level"] = "info") => {
      const log: AgentLog = {
        id: uid(),
        agentId,
        agentName,
        level,
        message,
        timestamp: new Date(),
      };
      setLogs((prev) => [log, ...prev].slice(0, 200));
    },
    []
  );

  const updateAgentStatus = useCallback((agentId: string, status: Agent["status"], currentTask?: string) => {
    setAgents((prev) =>
      prev.map((a) =>
        a.id === agentId
          ? { ...a, status, currentTask: currentTask ?? a.currentTask }
          : a
      )
    );
  }, []);

  const updateAgentStats = useCallback((agentId: string, tokens: number) => {
    setAgents((prev) =>
      prev.map((a) =>
        a.id === agentId
          ? { ...a, tasksCompleted: a.tasksCompleted + 1, tokensUsed: a.tokensUsed + tokens }
          : a
      )
    );
  }, []);

  const addTask = useCallback((task: AgentTask) => {
    setTasks((prev) => [task, ...prev]);
    return task;
  }, []);

  const updateTask = useCallback((taskId: string, patch: Partial<AgentTask>) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, ...patch } : t)));
  }, []);

  const delay = (ms: number) =>
    new Promise<void>((resolve) => {
      const t = setTimeout(resolve, ms);
      timeoutsRef.current.push(t);
    });

  const runPipeline = useCallback(
    async (pipelineId: string) => {
      if (isRunning) return;
      setIsRunning(true);
      setActivePipelineId(pipelineId);
      setTasks([]);
      setLogs([]);

      const pipeline = PIPELINES.find((p) => p.id === pipelineId)!;
      const scripts = TASK_SCRIPTS[pipelineId] || [];

      setPipelines((prev) =>
        prev.map((p) => (p.id === pipelineId ? { ...p, status: "running" } : p))
      );

      // Reset all agents
      setAgents((prev) => prev.map((a) => ({ ...a, status: "idle", currentTask: undefined })));

      addLog("system", "System", `🚀 流水线启动：${pipeline.name}`, "info");
      await delay(600);

      for (let stepIdx = 0; stepIdx < pipeline.steps.length; stepIdx++) {
        const step = pipeline.steps[stepIdx];
        const agentData = INITIAL_AGENTS.find((a) => a.id === step.agentId)!;
        const stepScripts = scripts[stepIdx] || ["正在处理...", "✅ 完成"];

        // Create task
        const task: AgentTask = {
          id: uid(),
          title: step.taskTemplate,
          agentId: step.agentId,
          status: "running",
          progress: 0,
          startedAt: new Date(),
        };
        addTask(task);

        // Set agent running
        updateAgentStatus(step.agentId, "running", step.taskTemplate);
        addLog(step.agentId, agentData.name, `▶️ 开始执行：${step.taskTemplate}`, "info");

        // Simulate progress with script lines
        const progressPerLine = 100 / stepScripts.length;
        for (let i = 0; i < stepScripts.length; i++) {
          await delay(700 + Math.random() * 600);
          updateTask(task.id, { progress: Math.round(progressPerLine * (i + 1)) });
          const level: AgentLog["level"] =
            stepScripts[i].includes("✅") ? "success" :
            stepScripts[i].includes("⚠️") ? "warn" :
            stepScripts[i].includes("🚨") ? "error" : "info";
          addLog(step.agentId, agentData.name, stepScripts[i], level);
        }

        // Finish task
        const tokensUsed = Math.floor(80000 + Math.random() * 320000);
        updateTask(task.id, {
          status: "done",
          progress: 100,
          finishedAt: new Date(),
          output: stepScripts[stepScripts.length - 1],
        });
        updateAgentStatus(step.agentId, "success");
        updateAgentStats(step.agentId, tokensUsed);
        addLog(
          step.agentId,
          agentData.name,
          `✅ 任务完成，消耗 ${(tokensUsed / 10000).toFixed(1)} 万 Token`,
          "success"
        );

        await delay(400);
        updateAgentStatus(step.agentId, "idle");
      }

      setPipelines((prev) =>
        prev.map((p) =>
          p.id === pipelineId ? { ...p, status: "success", lastRun: new Date() } : p
        )
      );
      addLog("system", "System", `🎉 流水线执行完毕：${pipeline.name}`, "success");
      setIsRunning(false);
    },
    [isRunning, addLog, addTask, updateTask, updateAgentStatus, updateAgentStats]
  );

  const stopAll = useCallback(() => {
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];
    setIsRunning(false);
    setAgents((prev) => prev.map((a) => ({ ...a, status: "idle", currentTask: undefined })));
    setPipelines((prev) => prev.map((p) => ({ ...p, status: "idle" })));
    addLog("system", "System", "⛔ 已手动停止所有任务", "warn");
  }, [addLog]);

  const clearLogs = useCallback(() => setLogs([]), []);

  return {
    agents,
    logs,
    tasks,
    pipelines,
    activePipelineId,
    isRunning,
    runPipeline,
    stopAll,
    clearLogs,
  };
}
